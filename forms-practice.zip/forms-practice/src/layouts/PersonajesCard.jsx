import React from 'react'
//
export const PersonajesCard = () => {
    return (
        <div>PersonajesCard</div>
    )
}
